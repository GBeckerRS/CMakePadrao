#include "foo.h"

void foo ()
{
    std::cout << "foo function" << std::endl;
}

