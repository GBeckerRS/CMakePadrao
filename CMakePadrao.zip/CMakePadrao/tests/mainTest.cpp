#define CATCH_CONFIG_MAIN
#include <catch2/catch.hpp>

#include "../include/foo.h"

TEST_CASE( "Quick check", "[main]" ) {
    foo ();
    REQUIRE( 1 == 1 );
}

