#include <iostream>

void foo ();

