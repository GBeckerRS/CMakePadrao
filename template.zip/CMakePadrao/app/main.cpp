#include <iostream>

#include "foo/foo.h"

int main (void) 
{
    std::cout << "Olá mundo!" << std::endl;
    foo ();

    return 0;
}

